'use strict';

/*
 * This file loads all of the php resources, and provides a resources object
 * that can call a function when all of the resources are done loading.
 *
 * Include this script before any other script that needs the resources to be
 * loaded, and wrap your code in
 *   resources.done(function() { <code> });
 * to execute <code> after the resources are done loading.
 */

var regions = $.getJSON('regions.php');
var teams = $.getJSON('teams.php');
var cities = $.getJSON('cities.php');

var resources = $.when(regions, teams, cities).done(function () {
    /* Unwrap all resources into plain objects */
    regions = regions.responseJSON.regions;
    teams = teams.responseJSON.teams;
    cities = cities.responseJSON.cities;

    /* Add arrays to hold ids of parent elements */
    $.each(regions, function(index, region) {
        region.city_ids = [];
    });
    $.each(cities, function(index, city) {
        city.team_ids = [];
    });

    /* Populate child arrays */
    $.each(cities, function(index, city, test) {
        regions[city.region_id - 1].city_ids.push(city.city_id);
    });
    $.each(teams, function(index, team) {
        cities[team.city_id - 1].team_ids.push(team.team_id);
    });
});

resources.fail(function() {
    alert('Resources failed to load. Please check that the web server is ' +
          'properly hosting the PHP resources and try again.');
});
