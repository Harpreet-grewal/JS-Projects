'use strict';

/* Javascript for pretty.html */

$(function() {
    resources.done(function () {
        function prettyJson(object, selector, title) {
            $(selector).html(
                '<h2>' + title + '</h2>' +
                    '<pre>' + JSON.stringify(object, null, 2) + '</pre>');
        }

        prettyJson(regions, '#regions', 'Pretty Printed Regions');
        prettyJson(cities, '#cities', 'Pretty Printed Cities');
        prettyJson(teams, '#teams', 'Pretty Printed Teams');
    });
});
