'use strict';

/* Main application javascript. */

$(document).ready(function() {
    var templates = {};
    var mapMarkers = [];
    var map;
    var lightbox = lity();
    var ignoreClose = false;

    addMap();
    prepareTemplates();
    resources.done(function() { /* When the php resources are done loading */
        addMapMarkers();
        render(decodeURI(window.location.hash));

        /* Every time hash changes, update what page is shown */
        $(window).on('hashchange', function() {
            render(decodeURI(window.location.hash));
        });
    });

    /* Workaround to set the hash to '' when the user closes the infobox. */
    $(document).on('lity:close', function() {
        if(!ignoreClose && window.location.hash !== '') {
            window.location.hash = '';
        }
        ignoreClose = false;
    });

    /* Renders the proper page based on the url hash */
    function render(hash) {
        if(hash === '') {
            lightbox.close();
            return;
        }

        hash = hash.split('-');

        switch(hash[0]) {
        case '#region': renderInfobox(hash[1]-1, 'regions-infobox', regions); break;
        case '#city': renderInfobox(hash[1]-1, 'cities-infobox', cities); break;
        case '#team': renderInfobox(hash[1]-1, 'teams-infobox', teams); break;
        case '#browse':
            switch(hash[1]) {
            case 'regions': browse('region', regions, 'All Regions'); break;
            case 'cities': browse('city', cities, 'All Cities'); break;
            case 'teams': browse('team', teams, 'All Teams'); break;
            default: window.location.hash = ''; break;
            }
            break;
        default: window.location.hash = ''; break;
        }

        /* Adapter function for browse infoboxes */
        function browse(type, items, title) {
            var obj = {
                type: type,
                items: items,
                title: title,
            };
            renderInfobox(0, 'browse-infobox', [obj]);
        }
    }

    /* Renders, prepares, and attaches infoboxes to the dom */
    function renderInfobox(index, type, database) {

        /* Delete all old infoboxes from the dom*/
        $('#infobox').remove();

        /* Chose the appropritae template, and apply it to the data */
        var infobox = $(templates[type](database[index]));

        $('body').append(infobox);

        /* Add functionality to the backbutton */
        infobox.find('.backbutton').click(function() {
            var hash = window.location.hash.split('-');

            switch(hash[0]) {
            case '#region': window.location.hash = ''; break;
            case '#city':
                ignoreClose = true;
                lightbox.close();
                window.location.hash = "region-" + String(cities[hash[1]-1].region_id);
                break;
            case '#team':
                ignoreClose = true;
                lightbox.close();
                window.location.hash = "city-" + String(teams[hash[1]-1].city_id);
                break;
            }
        });

        /* If a carousel exists, activate first photo in the carousel */
        var items = infobox.find('.carousel-inner>.item');
        if(items.length !== 0) {
            $(items[0]).addClass('active');
        }
        var indicators = infobox.find('.carousel-indicators>li');
        if(indicators.length !== 0) {
            $(indicators[0]).addClass('active');
        }

        /* Finally, activate the lightbox */
        lightbox('#infobox');
    }

    /* Creates new map, replacing #googleMap element with it */
    function addMap() {
        map = new google.maps.Map($('#googleMap').get()[0], {
            center: new google.maps.LatLng(40.4378693, -3.819963),
            zoom: 5,
            mapTypeId: google.maps.MapTypeId.ROADMAP
        });
    }

    /* Adds region markers to the map */
    function addMapMarkers() {
        $.each(regions, function(index, region){
            // region['long'] is used because long is a reserved keyword in javascript
            var latLng = { lat: Number(region.lat), lng: Number(region['long']) };

            mapMarkers[index] = new google.maps.Marker({
                position: latLng,
                map: map,
                title: region.region_name,
                icon: {
                    url: 'images/' + region.flag,
                    size: new google.maps.Size(40, 27),
                    scaledSize: new google.maps.Size(40, 27),
                },
            });

            /* Make region marker open infobox when clicked */
            mapMarkers[index].addListener('click', function() {
                window.location.hash ='region-' + (index+1);
            });
        });
    }

    /* Prepare everything related to handlebar templates */
    function prepareTemplates() {

        /* Little helper to make words plural or singular */
        Handlebars.registerHelper('plural', function(word, value) {
            switch(word) {
            case 'region':
            case 'regions':
                return value<2 ? 'region' : 'regions';
            case 'city':
            case 'cities':
                return value<2 ? 'city' : 'cities';
            case 'team':
            case 'teams':
                return value<2 ? 'team' : 'teams';
            }
        });

        /* Helpers to fetch the correct data for list-items */
        function browseHelper(type, item) {
            switch(type) {
            case 'region': return regionHelper(item.region_id);
            case 'city': return cityHelper(item.city_id);
            case 'team': return teamHelper(item.team_id);
            default: return null;
            }
        }
        function regionHelper(index) {
            var obj = { type: 'region' };
            obj.id = index;
            obj.image = regions[index-1].location;
            obj.name = regions[index-1].region_name;
            return obj;
        }
        function cityHelper(index) {
            var obj = { type: 'city' };
            obj.id = index;
            obj.image = cities[index-1].images[0].url;
            obj.name = cities[index-1].city_name;
            return obj;
        }
        function teamHelper(index) {
            var obj = { type: 'team' };
            obj.id = index;
            obj.image = teams[index-1].badge;
            obj.name = teams[index-1].team_name;
            return obj;
        }

        Handlebars.registerHelper({
            browseHelper: browseHelper,
            regionHelper: regionHelper,
            cityHelper: cityHelper,
            teamHelper: teamHelper,
        });

        /*
         * Find all templates and partials in the main document, and
         * compile and register them.
         */
        $('.partial-template').each(function(index, item) {
            Handlebars.registerPartial(item.id, item.innerHTML);
        });
        $('.template').each(function(index, item) {
            templates[item.id] = Handlebars.compile(item.innerHTML);
        });
    }
});
